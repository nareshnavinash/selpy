from src.driver import Driver
from src.locator import Locator
from src.store import Store
from src.variable import Var


class SelPy:

    def __init__(self):
        print("selpy script module")
